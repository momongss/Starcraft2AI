import numpy as np

a = np.zeros(shape=(500, 46))
print(a)