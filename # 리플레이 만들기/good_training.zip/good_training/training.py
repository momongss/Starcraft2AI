import pickle

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Model

import numpy as np
from architecture import get_compiled_Model

with open('good_replay.txt', 'rb') as fk:
    replay_data = pickle.load(fk)

ID = 0
ARGS = 1
OBS = 2


def normalize(v):
    norm = np.linalg.norm(v)
    if norm == 0:
       return v
    return v / norm


good_model = get_compiled_Model()

action_map = {1: 0, 2: 1, 451: 3, 3: 4, 7: 5, 490: 6, 42: 7, 13: 8, 91: 9, 477: 10}

for game_loop in sorted(replay_data.keys()):
    feature_screen = normalize(replay_data[game_loop][OBS]['feature_screen'])
    feature_minimap = normalize(replay_data[game_loop][OBS]['feature_minimap'])
    player = normalize(replay_data[game_loop][OBS]['player'])
    normalized_game_loop = np.array([game_loop / (22.4 * 1200)])

    action_id = replay_data[game_loop][ID]
    args = replay_data[game_loop][ARGS]

    feature_screen = feature_screen.reshape((1, 128, 128, 27))

    _, screen_x1, screen_y1, screen_x2, screen_y2, minimap_x, minimap_y = good_model.predict(x={
        'feature_screen': feature_screen,
        'feature_minimap': feature_minimap,
        'player': player,
        'game_loop': normalized_game_loop
    })
    print(action_id, args)

    if action_id == 1:
        continue

    action_type_logits = np.zeros(10)
    action_type_logits[action_map[action_id]] = 1
    if action_id == 2:
        screen_x1 = np.zeros(128)
        screen_y1[args[0][0]] = 1
    elif action_id == 451:
        screen_x1 = np.zeros(128)
        screen_y1[args[0][0]] = 1
    elif action_id == 3:
        screen_x1 = np.zeros(128)
        screen_y1[args[0][0]] = 1
        screen_x2 = np.zeros(128)
        screen_y2[args[0][1]] = 1
    elif action_id == 7:
        pass
    elif action_id == 490:
        pass
    elif action_id == 42:
        screen_x1 = np.zeros(128)
        screen_x1[args[0][0]] = 1
    elif action_id == 13:
        minimap_x = np.zeros(128)
        minimap_x[args[0][0]] = 1
        minimap_y = np.zeros(128)
        minimap_y[args[0][0]] = 1
    elif action_id == 91:
        screen_x1 = np.zeros(128)
        screen_x1[args[0][0]] = 1

    print(screen_x1, screen_y1)

    good_model.fit(x={
        'feature_screen': feature_screen,
        'feature_minimap': feature_minimap,
        'player': player,
        'game_loop': normalized_game_loop
    }, y={
        'action_type_logits': action_type_logits,
        'screen_x1': screen_x1,
        'screen_y1': screen_y1,
        'screen_x2': screen_x2,
        'screen_y2': screen_y2,
        'minimap_x': minimap_x,
        'minimap_y': minimap_y
    })