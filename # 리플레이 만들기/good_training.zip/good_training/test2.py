import pickle

with open('good_replay.txt', 'rb') as fk:
    replay_data = pickle.load(fk)

ID = 0
ARGS = 1
OBS = 2

count = {}

for game_loop in sorted(replay_data.keys()):
    feature_units = replay_data[game_loop][OBS]['feature_units']
    feature_minimap = replay_data[game_loop][OBS]['feature_minimap']
    player = replay_data[game_loop][OBS]['player']
    print(feature_units)
    # print(feature_units.shape)
    # m = 0
    # for f in feature_units[0]:
    #     m = max(m, max(f))
    #
    # print(m)