# AlphaStar pseudocode

`alphastar.py` - Describes RL training setup.
`rl.py` - Describes reinforcement learning update.
`multiagent.py` - Describes AlphaStar league.
`supervised.py` - Describes supervised learning setup.
